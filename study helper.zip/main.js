// ==========================================
// 1. MULTI-SUBJECT & CHAPTER DATABASE
// ==========================================
const STUDY_DB = {
  science: [
    {
      id: "sci_force",
      title: "Force and Pressure",
      quiz: [
        { q: "Pressure is mathematically defined as:", options: ["Force per unit area (F / A)", "Mass × Acceleration"], answer: 0 },
        { q: "If the surface area of contact decreases, the pressure:", options: ["Increases", "Decreases"], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Since your basics are strong, focus on fluid & atmospheric pressure: liquids exert equal pressure at the same depth ($P = \\rho gh$), and atmospheric pressure is balanced by our internal body pressure.",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>Force:</strong> A push or pull that changes an object's state of motion.<br>• <strong>Pressure:</strong> Force acting per unit area ($P = F / A$).<br>• <strong>Exam Tip:</strong> Smaller area = Higher pressure (why needles and knives have sharp edges).",
      worksheet: "Explain why school bags are provided with broad straps instead of thin strings.",
      flashcards: [
        { q: "What is the SI unit of Pressure?", a: "Pascal (Pa) or N/m²" },
        { q: "Give two examples of non-contact forces.", a: "Gravitational force and Magnetic force." },
        { q: "How does liquid pressure vary with depth?", a: "Liquid pressure increases as depth increases." }
      ],
      mindmap: [
        { name: "Contact Forces", detail: "Requires physical touch: Muscular force & Frictional force (always opposes motion)." },
        { name: "Non-Contact", detail: "Acts from a distance: Magnetic, Electrostatic, and Gravitational force." },
        { name: "Pressure (F/A)", detail: "Inversely proportional to area. Measured in Pascals (Pa) using manometers/barometers." }
      ],
      videos: [
        { title: "Force & Pressure One-Shot Visualized", duration: "14 mins", query: "Force and Pressure Class 8 Science One Shot" },
        { title: "Atmospheric & Liquid Pressure Experiments", duration: "9 mins", query: "Atmospheric Pressure Science Experiments Class 8" }
      ]
    },
    {
      id: "sci_coal",
      title: "Coal and Petroleum",
      quiz: [
        { q: "Which process converts dead vegetation into coal over millions of years?", options: ["Carbonisation", "Destructive Distillation"], answer: 0 },
        { q: "Which coal product is an almost pure form of carbon?", options: ["Coke", "Coal Tar"], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Focus on fractional distillation of petroleum in a refining tower—fractions separate by boiling points (Petroleum Gas < Petrol < Kerosene < Diesel < Bitumen).",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>Exhaustible Resources:</strong> Fossil fuels (Coal, Petroleum, Natural Gas) formed from dead organisms.<br>• <strong>Coke:</strong> Porous, pure carbon used in steel manufacturing.<br>• <strong>PCRA Tips:</strong> Drive at constant moderate speed and switch off engines at traffic lights.",
      worksheet: "Why are fossil fuels considered exhaustible natural resources? Give 2 conservation steps.",
      flashcards: [
        { q: "Which fuel is known as 'Black Gold'?", a: "Petroleum, due to its high commercial importance." },
        { q: "What is bitumen used for today?", a: "Metalling (surfacing) of roads and waterproofing." },
        { q: "Why is CNG preferred over petrol?", a: "It is a cleaner fuel that produces minimal smoke and ash." }
      ],
      mindmap: [
        { name: "Coal Products", detail: "Coke (pure carbon), Coal Tar (200+ substances), and Coal Gas (industrial fuel)." },
        { name: "Refining", detail: "Separation of petroleum constituents (LPG, Petrol, Diesel, Paraffin Wax) by boiling point." },
        { name: "Natural Gas", detail: "Stored under high pressure as CNG; transported via pipelines for power generation." }
      ],
      videos: [
        { title: "Coal & Petroleum Complete Revision", duration: "12 mins", query: "Coal and Petroleum Class 8 Science Revision" },
        { title: "How Fractional Distillation Works", duration: "7 mins", query: "Fractional Distillation of Petroleum Animation" }
      ]
    }
  ],
  maths: [
    {
      id: "math_linear",
      title: "Linear Equations in One Variable",
      quiz: [
        { q: "If 2x - 3 = 7, what is the value of x?", options: ["x = 5", "x = 2"], answer: 0 },
        { q: "What is the highest power of the variable in a linear equation?", options: ["1", "2"], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Focus on cross-multiplication equations of the form $(ax+b)/(cx+d) = m/n$ and word problems involving ages, digit reversal, and perimeter.",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>Transposition Rule:</strong> Moving a term across '=' flips its sign ($+$ becomes $-$, $\\times$ becomes $\\div$).<br>• <strong>Strategy:</strong> Bring all variable terms ($x$) to the LHS and constants to the RHS.",
      worksheet: "Solve step-by-step: 5x + 9 = 5 + 3x, and verify your answer by substituting x.",
      flashcards: [
        { q: "Solve: 3x = 2x + 18", a: "Subtract 2x from both sides: x = 18." },
        { q: "How do you represent a two-digit number with tens digit 't' and units digit 'u'?", a: "10t + u" },
        { q: "What happens when you multiply both sides of an equation by the same non-zero number?", a: "The equality remains unchanged." }
      ],
      mindmap: [
        { name: "Transposition", detail: "Shift terms across '=' by inverting operations (+ to -, * to /)." },
        { name: "LCM Method", detail: "Multiply all terms by the LCM of denominators to clear fractions first." },
        { name: "Word Problems", detail: "Assign 'x' to the unknown quantity, frame the equality, and solve." }
      ],
      videos: [
        { title: "Linear Equations Tricks & Word Problems", duration: "16 mins", query: "Linear Equations in One Variable Class 8 Maths" },
        { title: "Age & Number Word Problems Made Easy", duration: "11 mins", query: "Linear Equations Word Problems Class 8" }
      ]
    },
    {
      id: "math_mensuration",
      title: "Mensuration (Area & Volume)",
      quiz: [
        { q: "What is the formula for the area of a trapezium?", options: ["½ × h × (a + b)", "Base × Height"], answer: 0 },
        { q: "1 cubic metre (1 m³) is equal to how many litres?", options: ["1000 Litres", "100 Litres"], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Pay close attention to Lateral Surface Area (LSA) vs Total Surface Area (TSA) of cylinders: $LSA = 2\\pi rh$, whereas $TSA = 2\\pi r(r + h)$.",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>Area of Rhombus:</strong> $\\frac{1}{2} \\times d_1 \\times d_2$<br>• <strong>Volume of Cube:</strong> $l^3$ | <strong>Cuboid:</strong> $l \\times b \\times h$<br>• <strong>Volume of Cylinder:</strong> $\\pi r^2 h$",
      worksheet: "Find the height of a cylinder whose radius is 7 cm and total surface area is 968 cm².",
      flashcards: [
        { q: "Formula for Total Surface Area of a Cube of side 'a'?", a: "6a²" },
        { q: "Formula for Lateral Surface Area of a Cuboid?", a: "2h(l + b)" },
        { q: "Volume of a Cylinder?", a: "πr²h" }
      ],
      mindmap: [
        { name: "2D Polygons", detail: "Trapezium: ½h(a+b) | Rhombus: ½ × d₁ × d₂" },
        { name: "Surface Area", detail: "Cube: 6a² | Cuboid: 2(lb+bh+hl) | Cylinder: 2πr(r+h)" },
        { name: "3D Volume", detail: "Space occupied: Base Area × Height. 1 m³ = 1000 L." }
      ],
      videos: [
        { title: "All Mensuration Formulas without Memorizing", duration: "13 mins", query: "Mensuration Class 8 Formulas Explained" }
      ]
    }
  ],
  social: [
    {
      id: "sst_resources",
      title: "Resources & Sustainable Development",
      quiz: [
        { q: "What turns any substance into a 'Resource'?", options: ["Utility (Usability) and Value", "Abundance in nature"], answer: 0 },
        { q: "Balancing the need to use resources and conserving them for the future is called:", options: ["Sustainable Development", "Resource Extraction"], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Connect Human Resource Development (skill + technology) with how localized resources transition from potential to actual resources.",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>3 Types:</strong> Natural, Human-Made, and Human Resources.<br>• <strong>Time & Technology:</strong> The two key factors that turn substances into resources.<br>• <strong>3 R's:</strong> Reduce, Recycle, and Reuse.",
      worksheet: "Differentiate between Ubiquitous and Localized resources with one example each.",
      flashcards: [
        { q: "What is Patent?", a: "The exclusive right over any idea or invention." },
        { q: "Define Stock of Resource.", a: "The amount of resources available for use." },
        { q: "What is Human Resource Development?", a: "Improving the quality of people's skills so they can create more resources." }
      ],
      mindmap: [
        { name: "Natural", detail: "Renewable (Solar, Wind) vs Non-Renewable (Coal, Petroleum)." },
        { name: "Human", detail: "Education and health make people valuable resources." },
        { name: "Sustainability", detail: "Conserving Earth's vitality and diversity for future generations." }
      ],
      videos: [
        { title: "Resources Class 8 Geography Full Chapter", duration: "10 mins", query: "Resources Class 8 Geography One Shot" }
      ]
    }
  ],
  english: [
    {
      id: "eng_voice",
      title: "Active and Passive Voice",
      quiz: [
        { q: "In Passive Voice, the main verb is always in which form?", options: ["Past Participle (V3)", "Present Continuous (-ing)"], answer: 0 },
        { q: "Convert to Passive: 'Aniket wrote a clean code.'", options: ["A clean code was written by Aniket.", "A clean code is written by Aniket."], answer: 0 }
      ],
      summaryHigh: "🌟 <strong>Fast-Track Mastery:</strong> Focus on interrogative sentences ('Who wrote this?' → 'By whom was this written?') and imperative commands ('Close the door' → 'Let the door be closed').",
      summaryBase: "🧱 <strong>Core Foundation:</strong><br>• <strong>Rule 1:</strong> Swap Subject and Object.<br>• <strong>Rule 2:</strong> Always use the <strong>V3 (Past Participle)</strong> form of the main verb.<br>• <strong>Rule 3:</strong> Add the appropriate 'be' helper verb (is/am/are/was/were/been/being).",
      worksheet: "Change into passive voice: 'The team is developing an automated study prototype.'",
      flashcards: [
        { q: "Simple Present Passive Formula?", a: "Object + is/am/are + V3 + by + Subject" },
        { q: "Past Continuous Passive Formula?", a: "Object + was/were + being + V3 + by + Subject" },
        { q: "How does 'I' and 'They' change in the object position?", a: "'I' becomes 'me'; 'They' becomes 'them'." }
      ],
      mindmap: [
        { name: "Pronoun Shift", detail: "I → me, We → us, He → him, She → her, They → them." },
        { name: "Continuous", detail: "Add 'being' + V3 (e.g., is being built, was being tested)." },
        { name: "Perfect Tense", detail: "Add 'been' + V3 (e.g., has been completed, had been solved)." }
      ],
      videos: [
        { title: "Active & Passive Voice Master Chart", duration: "12 mins", query: "Active and Passive Voice Rules Class 8 English" }
      ]
    }
  ]
};

// Motivational Quotes
const QUOTES = [
  "\"Success is the sum of small efforts, repeated day in and day out.\"",
  "\"Don't study until you get it right. Study until you can't get it wrong.\"",
  "\"Focus on progress, not perfection. Every 30-minute block counts!\"",
  "\"Discipline is choosing between what you want now and what you want most.\"",
  "\"A topper isn't born overnight—they are built one concept at a time.\""
];

// Global State
let xp = 140;
let quoteIdx = 0;
let currentChapter = null;
let cardIndex = 0;
let showingAnswer = false;
let selectedDayIndex = 0;
let activeScheduleTaskId = null;
let scheduleData = [];

// ==========================================
// 2. INITIALIZATION & NAVIGATION
// ==========================================
window.onload = () => {
  populateChapters();
  initCalendarStrip();
  renderSyllabusChecklist();
  generateSchedule();
  updateApiBadge();
};

function switchMainTab(tabId, btn) {
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.add("hidden"));
  document.getElementById("tab-" + tabId).classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
}

function switchLearnTool(toolId, btn) {
  document.querySelectorAll(".learn-tool").forEach(t => t.classList.add("hidden"));
  document.getElementById("tool-" + toolId).classList.remove("hidden");
  btn.parentElement.querySelectorAll(".pill-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
}

function nextQuote() {
  quoteIdx = (quoteIdx + 1) % QUOTES.length;
  document.getElementById("motivation-text").innerText = QUOTES[quoteIdx];
}

function addXP(pts) {
  xp += pts;
  document.getElementById("xp-count").innerText = xp;
  const rankBadge = document.getElementById("rank-badge");
  if (xp >= 250) rankBadge.innerText = "👑 Lv.4 Grandmaster";
  else if (xp >= 180) rankBadge.innerText = "⚡ Lv.3 Focus Ninja";
}

// ==========================================
// 3. CHAPTER LOADER & DIAGNOSTIC ENGINE
// ==========================================
function populateChapters() {
  const subj = document.getElementById("subject-select").value;
  const chapSelect = document.getElementById("chapter-select");
  chapSelect.innerHTML = "";
  STUDY_DB[subj].forEach((ch, idx) => {
    const opt = document.createElement("option");
    opt.value = idx;
    opt.innerText = ch.title;
    chapSelect.appendChild(opt);
  });
  loadSelectedChapter();
}

function loadSelectedChapter() {
  const subj = document.getElementById("subject-select").value;
  const idx = document.getElementById("chapter-select").value || 0;
  currentChapter = STUDY_DB[subj][idx];

  document.getElementById("chapter-badge").innerText = currentChapter.title;
  document.getElementById("adaptive-lesson").classList.add("hidden");
  document.getElementById("ai-generated-q").classList.add("hidden");

  // Render Diagnostic Quiz
  const qBox = document.getElementById("quiz-container");
  qBox.innerHTML = "";
  currentChapter.quiz.forEach((qItem, qIdx) => {
    qBox.innerHTML += `
      <div class="quiz-q">
        <p>Q${qIdx + 1}: ${qItem.q}</p>
        ${qItem.options.map((opt, oIdx) => `
          <label>
            <input type="radio" name="diag_q${qIdx}" value="${oIdx}">
            ${opt}
          </label>
        `).join("")}
      </div>
    `;
  });

  // Render Flashcards
  cardIndex = 0;
  showingAnswer = false;
  renderCard();

  // Render Interactive Mind Map
  document.getElementById("mm-root-node").innerText = currentChapter.title;
  const branchesBox = document.getElementById("mm-branches-box");
  branchesBox.innerHTML = "";
  currentChapter.mindmap.forEach((node, i) => {
    branchesBox.innerHTML += `
      <div class="mm-node" onclick="showMindMapDetail(${i})">
        ${node.name}
      </div>
    `;
  });
  document.getElementById("mm-detail-box").innerHTML = "👆 Tap any sub-branch above to inspect its key exam formula or summary.";

  // Render YouTube Cards
  const ytBox = document.getElementById("yt-list");
  ytBox.innerHTML = "";
  currentChapter.videos.forEach(v => {
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(v.query)}`;
    ytBox.innerHTML += `
      <a href="${url}" target="_blank" class="yt-card">
        <div class="yt-info">
          <strong>${v.title}</strong>
          <small>⏱️ ${v.duration} • Curated Topic Search</small>
        </div>
        <span class="yt-play-btn">▶ Watch</span>
      </a>
    `;
  });

  // Load chapter-specific notes
  const savedNote = localStorage.getItem("notes_" + currentChapter.id) || "";
  document.getElementById("saved-notes").value = savedNote;
}

function evaluateDiagnostic() {
  let score = 0;
  currentChapter.quiz.forEach((qItem, qIdx) => {
    const picked = document.querySelector(`input[name="diag_q${qIdx}"]:checked`);
    if (picked && parseInt(picked.value) === qItem.answer) score++;
  });

  const lessonBox = document.getElementById("lesson-content");
  document.getElementById("adaptive-lesson").classList.remove("hidden");
  document.getElementById("worksheet-question").innerText = currentChapter.worksheet;

  if (score === currentChapter.quiz.length) {
    lessonBox.innerHTML = `<div style="margin-bottom:6px; color:#fde047; font-weight:700;">Score: ${score}/${currentChapter.quiz.length} (Advanced Track)</div>` + currentChapter.summaryHigh;
  } else {
    lessonBox.innerHTML = `<div style="margin-bottom:6px; color:#38bdf8; font-weight:700;">Score: ${score}/${currentChapter.quiz.length} (Foundation Builder)</div>` + currentChapter.summaryBase;
  }
  addXP(15);
}

function showMindMapDetail(idx) {
  const node = currentChapter.mindmap[idx];
  document.getElementById("mm-detail-box").innerHTML = `<strong>📌 ${node.name}:</strong> ${node.detail}`;
}

function completeWorksheet() {
  addXP(20);
  triggerReminder("✅ Subtopic Worksheet Completed! +20 XP earned.");
}

// Flashcard Controls
function renderCard() {
  const item = currentChapter.flashcards[cardIndex];
  document.getElementById("fc-label").innerText = showingAnswer ? "ANSWER (TAP TO FLIP)" : "QUESTION (TAP TO FLIP)";
  document.getElementById("fc-text").innerText = showingAnswer ? item.a : item.q;
  document.getElementById("fc-index").innerText = `${cardIndex + 1} / ${currentChapter.flashcards.length}`;
}

function flipCard() {
  showingAnswer = !showingAnswer;
  renderCard();
}

function nextCard(dir) {
  const len = currentChapter.flashcards.length;
  cardIndex = (cardIndex + dir + len) % len;
  showingAnswer = false;
  renderCard();
}

// Save Chapter Notes
function saveUserNotes() {
  const val = document.getElementById("saved-notes").value;
  localStorage.setItem("notes_" + currentChapter.id, val);
  triggerReminder(`💾 Notes saved for ${currentChapter.title}!`);
}

// ==========================================
// 4. LIVE GEMINI API + OFFLINE AI ENGINE
// ==========================================
function toggleApiModal() {
  const modal = document.getElementById("api-modal");
  modal.classList.toggle("hidden");
  document.getElementById("gemini-key-input").value = localStorage.getItem("omnistudy_gemini_key") || "";
}

function saveApiKey() {
  const key = document.getElementById("gemini-key-input").value.trim();
  if (key) {
    localStorage.setItem("omnistudy_gemini_key", key);
    triggerReminder("🤖 Live Gemini API Key Saved!");
  } else {
    localStorage.removeItem("omnistudy_gemini_key");
    triggerReminder("🔌 Switched to Built-in Offline AI Engine.");
  }
  updateApiBadge();
  toggleApiModal();
}

function updateApiBadge() {
  const hasKey = !!localStorage.getItem("omnistudy_gemini_key");
  const badge = document.getElementById("ai-mode-tag");
  if (badge) badge.innerText = hasKey ? "⚡ Live Gemini AI" : "Offline Engine";
}

async function callGeminiAPI(promptText) {
  const apiKey = localStorage.getItem("omnistudy_gemini_key");
  if (!apiKey) return null;

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: promptText }] }]
    })
  });
  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || null;
}

async function generateAIQuestion() {
  const out = document.getElementById("ai-generated-q");
  out.classList.remove("hidden");
  out.innerHTML = "⏳ Generating fresh exam question...";

  try {
    const liveReply = await callGeminiAPI(
      `Generate 1 short Class 8 exam question and a 2-line model answer on the chapter "${currentChapter.title}". Format clearly in plain text.`
    );
    if (liveReply) {
      out.innerHTML = `<strong>✨ Gemini Live Question:</strong><br>${liveReply.replace(/\n/g, "<br>")}`;
      addXP(10);
      return;
    }
  } catch (e) {
    // Fallback to offline generator if offline or key invalid
  }

  // Offline Fallback Question Bank
  const fc = currentChapter.flashcards[Math.floor(Math.random() * currentChapter.flashcards.length)];
  out.innerHTML = `<strong>✨ AI Practice Question:</strong> ${fc.q}<br><em>💡 Hint / Model Key:</em> ${fc.a}`;
  addXP(10);
}

async function improveAnswer() {
  const raw = document.getElementById("rough-answer").value.trim();
  const out = document.getElementById("improved-output");
  out.classList.remove("hidden");

  if (!raw) {
    out.innerHTML = "⚠️ Please type or paste a rough answer first.";
    return;
  }

  out.innerHTML = "⏳ Analyzing concept accuracy & upgrading presentation...";

  try {
    const liveReply = await callGeminiAPI(
      `You are a supportive Class 8 school teacher. A student wrote this answer for the chapter "${currentChapter.title}": "${raw}". 
      1. Point out any conceptual mistake gently.
      2. Rewrite it into a 3-point full-marks exam answer (Core Principle, Explanation, Conclusion). Keep it concise.`
    );
    if (liveReply) {
      out.innerHTML = liveReply.replace(/\n/g, "<br>");
      addXP(15);
      return;
    }
  } catch (e) {
    // Fallback to offline coach
  }

  // Smart Offline Teacher Formatter
  out.innerHTML = `
    <strong>👩‍🏫 Teacher-Approved 3-Mark Format (${currentChapter.title}):</strong><br><br>
    <strong>1. Core Scientific/Key Principle:</strong> State the exact definition or formula from <em>${currentChapter.title}</em> first.<br>
    <strong>2. Refined Explanation:</strong> "${raw}" → <em>Upgraded:</em> Due to this principle, the relationship between the variables directly explains the observation.<br>
    <strong>3. Exam Conclusion:</strong> Therefore, this applications works efficiently in real-world scenarios. <em>(Underline key terms in your exam sheet!)</em>
  `;
  addXP(15);
}

// ==========================================
// 5. SYNCHRONISED CALENDAR & PROGRESS
// ==========================================
function initCalendarStrip() {
  const strip = document.getElementById("calendar-strip");
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const today = new Date();
  strip.innerHTML = "";

  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(today.getDate() + i);
    const dayName = days[d.getDay()];
    const dateNum = d.getDate();

    const el = document.createElement("div");
    el.className = "cal-day" + (i === selectedDayIndex ? " active" : "");
    el.innerHTML = `<small>${dayName}</small><strong>${dateNum}</strong>`;
    el.onclick = () => {
      selectedDayIndex = i;
      initCalendarStrip();
      generateSchedule();
    };
    strip.appendChild(el);
  }
}

function generateSchedule() {
  const hours = parseInt(document.getElementById("study-hours").value) || 2;
  const energy = document.getElementById("energy-level").value;
  const container = document.getElementById("schedule-output");

  // Update Burnout Status
  const badge = document.getElementById("burnout-badge");
  const advice = document.getElementById("burnout-advice");
  if (energy === "low") {
    badge.className = "badge badge-warn";
    badge.innerText = "⚠️ Low Energy";
    advice.innerHTML = "🛡️ <strong>Burnout Preventor Triggered:</strong> Since your energy is Low, your calendar blocks have been automatically switched to lighter 20-minute Flashcard & Video sessions with longer recovery breaks.";
  } else {
    badge.className = "badge badge-ok";
    badge.innerText = "🌿 Balanced";
    advice.innerHTML = "✅ <strong>Balanced Pace:</strong> Your 30-minute study cycles with 5-minute breaks keep memory retention high without exhausting your brain.";
  }

  const allChapters = [
    ...STUDY_DB.science,
    ...STUDY_DB.maths,
    ...STUDY_DB.social,
    ...STUDY_DB.english
  ];

  scheduleData = [];
  const blocks = hours * 2;
  let hr = 16;
  let min = 0;

  for (let i = 0; i < blocks; i++) {
    const ch = allChapters[(i + selectedDayIndex) % allChapters.length];
    const timeStr = `${hr}:${min === 0 ? "00" : min < 10 ? "0" + min : min}`;
    const modeLabel = energy === "low" ? "Light Flashcards & Video" : "Deep Study & Worksheet";

    scheduleData.push({
      id: "task_" + i,
      time: timeStr,
      title: `${ch.title} (${modeLabel})`,
      loggedMinutes: 0,
      completed: false
    });

    min += 35;
    if (min >= 60) {
      hr++;
      min -= 60;
    }
  }

  renderScheduleList();
}

function renderScheduleList() {
  const container = document.getElementById("schedule-output");
  container.innerHTML = "";

  scheduleData.forEach(item => {
    container.innerHTML += `
      <div class="schedule-item ${item.completed ? 'done' : ''}">
        <div>
          <strong>🕒 ${item.time} — ${item.title}</strong>
          <div class="subtext" style="margin:2px 0 0;">
            ${item.loggedMinutes > 0 ? `✅ Synced: ${item.loggedMinutes} mins logged` : "⏳ Not started yet"}
          </div>
        </div>
        <button class="btn-primary" style="padding:8px 12px; font-size:0.8rem;" onclick="syncTaskToTimer('${item.id}')">
          ▶ Start
        </button>
      </div>
    `;
  });
}

// Syncs a Calendar event directly to the Focus Timer & Stopwatch
function syncTaskToTimer(taskId) {
  const task = scheduleData.find(t => t.id === taskId);
  if (!task) return;

  activeScheduleTaskId = task.id;
  document.getElementById("active-timer-task").innerText = `📌 Synced: ${task.title}`;
  document.getElementById("sync-task-name").innerText = `⏱️ ${task.title}`;
  document.getElementById("sync-bar").classList.remove("hidden");

  // Switch to Timer Tab and auto-start 30m Pomodoro
  switchMainTab("focus", document.getElementById("nav-focus"));
  setTimerMode("pomo30", document.getElementById("mode-pomo30"));
  toggleTimer();
  triggerReminder(`🔗 Calendar task synced to Timer!`);
}

// Syllabus Checklist
function renderSyllabusChecklist() {
  const box = document.getElementById("syllabus-checklist");
  const allChapters = [
    ...STUDY_DB.science,
    ...STUDY_DB.maths,
    ...STUDY_DB.social,
    ...STUDY_DB.english
  ];
  box.innerHTML = "";
  allChapters.forEach((ch, idx) => {
    const checked = idx < 2 ? "checked" : "";
    box.innerHTML += `
      <label>
        <input type="checkbox" class="chap-check" ${checked} onchange="updateProgress()">
        ${ch.title}
      </label>
    `;
  });
  updateProgress();
}

function updateProgress() {
  const checks = document.querySelectorAll(".chap-check");
  const done = Array.from(checks).filter(c => c.checked).length;
  const pct = Math.round((done / checks.length) * 100);
  document.getElementById("progress-percent").innerText = pct + "%";
  document.getElementById("progress-fill").style.width = pct + "%";
}

// ==========================================
// 6. SYNCHRONISED TIMER, STOPWATCH & AUDIO
// ==========================================
let timerSeconds = 1800;
let elapsedSeconds = 0;
let timerInterval = null;
let currentMode = "pomo30";

function setTimerMode(mode, btn) {
  clearInterval(timerInterval);
  timerInterval = null;
  document.getElementById("timer-start-btn").innerText = "▶ Start";
  currentMode = mode;
  elapsedSeconds = 0;

  btn.parentElement.querySelectorAll(".pill-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");

  if (mode === "pomo30") {
    timerSeconds = 1800;
  } else if (mode === "break5") {
    timerSeconds = 300;
  } else {
    timerSeconds = 0;
  }
  updateTimerDisplay();
}

function updateTimerDisplay() {
  const m = String(Math.floor(timerSeconds / 60)).padStart(2, "0");
  const s = String(timerSeconds % 60).padStart(2, "0");
  const formatted = `${m}:${s}`;
  document.getElementById("timer-display").innerText = formatted;
  document.getElementById("sync-mini-time").innerText = formatted;
}

function toggleTimer() {
  const btn = document.getElementById("timer-start-btn");
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
    btn.innerText = "▶ Resume";
  } else {
    btn.innerText = "⏸ Pause";
    timerInterval = setInterval(() => {
      elapsedSeconds++;
      if (currentMode === "stopwatch") {
        timerSeconds++;
      } else {
        if (timerSeconds > 0) {
          timerSeconds--;
        } else {
          logAndResetTimer();
          triggerReminder("🎉 Session Complete! Time logged to your calendar.");
        }
      }
      updateTimerDisplay();
    }, 1000);
  }
}

function logAndResetTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  document.getElementById("timer-start-btn").innerText = "▶ Start";

  // Log minutes back to synced calendar task
  const minsLogged = Math.max(1, Math.round(elapsedSeconds / 60));
  if (activeScheduleTaskId && elapsedSeconds > 5) {
    const task = scheduleData.find(t => t.id === activeScheduleTaskId);
    if (task) {
      task.loggedMinutes += minsLogged;
      task.completed = true;
      renderScheduleList();
      addXP(30);
      triggerReminder(`✅ Logged ${minsLogged}m to "${task.title}" (+30 XP)`);
    }
  } else if (elapsedSeconds > 5) {
    addXP(15);
    triggerReminder(`✅ Study session logged! (+15 XP)`);
  }

  elapsedSeconds = 0;
  timerSeconds = currentMode === "pomo30" ? 1800 : currentMode === "break5" ? 300 : 0;
  updateTimerDisplay();
}

// Web Audio API Calming Focus Drone + MP3 Player
let audioCtx = null;
let osc = null;

function toggleFocusDrone() {
  const btn = document.getElementById("synth-btn");
  if (!osc) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(174, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    btn.innerText = "⏹ Stop Drone";
  } else {
    osc.stop();
    osc = null;
    btn.innerText = "🌊 Calm Drone";
  }
}

function loadLocalMp3(event) {
  const file = event.target.files[0];
  if (file) {
    const player = document.getElementById("audio-player");
    player.src = URL.createObjectURL(file);
    player.classList.remove("hidden");
    player.play();
  }
}

// ==========================================
// 7. BREAK MINI-GAME & TOAST ALERTS
// ==========================================
let gameScore = 0;
function hitTarget() {
  gameScore++;
  document.getElementById("game-score").innerText = gameScore;
  const target = document.getElementById("game-target");
  target.style.top = Math.floor(Math.random() * 105) + "px";
  target.style.left = Math.floor(Math.random() * 80) + "%";
  if (gameScore % 5 === 0) addXP(5);
}

function triggerReminder(msg) {
  document.getElementById("toast-text").innerText = msg;
  document.getElementById("toast-banner").classList.remove("hidden");
}

function closeToast() {
  document.getElementById("toast-banner").classList.add("hidden");
}